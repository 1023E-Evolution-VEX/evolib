#pragma once
#include "evolib/asset.hpp"
#include "evolib/exitcondition.hpp"
#include "evolib/pid.hpp"
#include "evolib/trackingWheel.hpp"
#include "pose.hpp"
#include "pros/imu.hpp"
#include "pros/motor_group.hpp"
#include "pros/motors.hpp"
namespace evolib {

class OdomSensors {
   public:
    OdomSensors(TrackingWheel* vertical, TrackingWheel* horizontal,
                pros::Imu* imu);
    TrackingWheel* vertical;
    TrackingWheel* horizontal;
    pros::Imu* imu;
};

/**
 * @brief class containing constants for a chassis controller
 */
class ControllerSettings {
   public:
    ControllerSettings(float kP, float kI, float kD, float windupRange,
                       float smallError, float smallErrorTimeout,
                       float largeError, float largeErrorTimeout, float slew)
        : kP(kP),
          kI(kI),
          kD(kD),
          windupRange(windupRange),
          smallError(smallError),
          smallErrorTimeout(smallErrorTimeout),
          largeError(largeError),
          largeErrorTimeout(largeErrorTimeout),
          slew(slew) {}

    float kP;
    float kI;
    float kD;
    float windupRange;
    float smallError;
    float smallErrorTimeout;
    float largeError;
    float largeErrorTimeout;
    float slew;
};

enum class AngularDirection {
    CW_CLOCKWISE,         /** turn clockwise */
    CCW_COUNTERCLOCKWISE, /** turn counter-clockwise */
    AUTO /** turn in the direction with the shortest distance to target */
};
struct TurnToPointParams {
    /** whether the robot should turn to face the point with the front of the
     * robot. True by default */
    bool forwards = true;
    /** the direction the robot should turn in. AUTO by default */
    AngularDirection direction = AngularDirection::AUTO;
    /** the maximum speed the robot can turn at. Value between 0-127. 127 by
     * default */
    int maxSpeed = 127;
    /** the minimum speed the robot can turn at. If set to a non-zero value, the
     * `it conditions will switch to less accurate but smoother ones. Value
     * between 0-127. 0 by default */
    int minSpeed = 0;
    /** angle between the robot and target point where the movement will exit.
     * Only has an effect if minSpeed is non-zero.*/
    float earlyExitRange = 0;
};
struct TurnToHeadingParams {
    /** the direction the robot should turn in. AUTO by default */
    AngularDirection direction = AngularDirection::AUTO;
    /** the maximum speed the robot can turn at. Value between 0-127. 127 by
     * default */
    int maxSpeed = 127;
    /** the minimum speed the robot can turn at. If set to a non-zero value, the
     * `it conditions will switch to less accurate but smoother ones. Value
     * between 0-127. 0 by default */
    int minSpeed = 0;
    /** angle between the robot and target point where the movement will exit.
     * Only has an effect if minSpeed is non-zero.*/
    float earlyExitRange = 0;
};
enum class DriveSide {
    LEFT, /** lock the left side of the drivetrain */
    RIGHT /** lock the right side of the drivetrain */
};
struct SwingToPointParams {
    /** whether the robot should turn to face the point with the front of the
     * robot. True by default */
    bool forwards = true;
    /** the direction the robot should turn in. AUTO by default */
    AngularDirection direction = AngularDirection::AUTO;
    /** the maximum speed the robot can turn at. Value between 0-127. 127 by
     * default */
    float maxSpeed = 127;
    /** the minimum speed the robot can turn at. If set to a non-zero value, the
     * exit conditions will switch to less accurate but smoother ones. Value
     * between 0-127. 0 by default */
    float minSpeed = 0;
    /** angle between the robot and target heading where the movement will exit.
     * Only has an effect if minSpeed is non-zero.*/
    float earlyExitRange = 0;
};
struct SwingToHeadingParams {
    /** the direction the robot should turn in. AUTO by default */
    AngularDirection direction = AngularDirection::AUTO;
    /** the maximum speed the robot can turn at. Value between 0-127. 127 by
     * default */
    float maxSpeed = 127;
    /** the minimum speed the robot can turn at. If set to a non-zero value, the
     * exit conditions will switch to less accurate but smoother ones. Value
     * between 0-127. 0 by default */
    float minSpeed = 0;
    /** angle between the robot and target heading where the movement will exit.
     * Only has an effect if minSpeed is non-zero.*/
    float earlyExitRange = 0;
};
struct BoomerangParams {
    /** whether the robot should move forwards or backwards. True by default */
    bool forwards = true;
    /** how fast the robot will move around corners. Recommended value 2-15. 0
     * means use horizontalDrift set in chassis class. 0 by default. */
    float horizontalDrift = 0;
    /** carrot point multiplier. value between 0 and 1. Higher values result in
     * curvier movements. 0.6 by default */
    float lead = 0.6;
    /** the maximum speed the robot can travel at. Value between 0-127. 127 by
     * default */
    float maxSpeed = 127;
    /** the minimum speed the robot can travel at. If set to a non-zero value,
     * the exit conditions will switch to less accurate but smoother ones. Value
     * between 0-127. 0 by default */
    float minSpeed = 0;
    /** distance between the robot and target point where the movement will
     * exit. Only has an effect if minSpeed is non-zero.*/
    float earlyExitRange = 0;
};
struct MoveToPointParams {
    /** whether the robot should move forwards or backwards. True by default */
    bool forwards = true;
    /** the maximum speed the robot can travel at. Value between 0-127. 127 by
     * default */
    float maxSpeed = 127;
    /** the minimum speed the robot can travel at. If set to a non-zero value,
     * the exit conditions will switch to less accurate but smoother ones. Value
     * between 0-127. 0 by default */
    float minSpeed = 0;
    /** distance between the robot and target point where the movement will
     * exit. Only has an effect if minSpeed is non-zero.*/
    float earlyExitRange = 0;
};
struct MoveToPoint2Params {
    /** whether the robot should move forwards or backwards. True by default */
    bool forwards = true;
    float turnPower = 11;
    float settleFactor = 4;
    /** the maximum speed the robot can travel at. Value between 0-127. 127 by
     * default */
    float maxSpeed = 127;
    /** the minimum speed the robot can travel at. If set to a non-zero value,
     * the exit conditions will switch to less accurate but smoother ones. Value
     * between 0-127. 0 by default */
    float minSpeed = 0;
    /** distance between the robot and target point where the movement will
     * exit. Only has an effect if minSpeed is non-zero.*/
    float earlyExitRange = 0;
};
struct MoveForDistanceParams {
    bool forwards = true;
    float maxSpeed = 127;
    float minSpeed = 0;
    bool chain = false;
};
class Drivetrain {
   public:
    Drivetrain(pros::MotorGroup* leftMotors, pros::MotorGroup* rightMotors,
               float horizontalDrift);
    pros::MotorGroup* leftMotors;
    pros::MotorGroup* rightMotors;
    float horizontalDrift;
};

class Robot {
   public:
    Robot(Drivetrain dt, ControllerSettings linearSettings,
          ControllerSettings angularSettings, OdomSensors sensors);

    void calibrate();
    void setPose(float x, float y, float theta);
    void setPose(Pose pose);
    void setX(float x);
    void setY(float y);
    Pose getPose(bool radians = false, bool standardPos = false);

    void setBrakeType(pros::motor_brake_mode_e_t mode);
    void turnToPoint(float x, float y, int timeout,
                     TurnToPointParams params = {}, bool async = true);
    void turnToHeading(float theta, int timeout,
                       TurnToHeadingParams params = {}, bool async = true);

    void swingToHeading(float theta, DriveSide lockedSide, int timeout,
                        SwingToHeadingParams params = {}, bool async = true);
    void swingToPoint(float x, float y, DriveSide lockedSide, int timeout,
                      SwingToPointParams params = {}, bool async = true);
    void boomerang(float x, float y, float theta, int timeout,
                   BoomerangParams params = {}, bool async = true);
    void moveToPoint(float x, float y, int timeout,
                     MoveToPointParams params = {}, bool async = true);
    void moveToPoint2(float x, float y, int timeout,
                     MoveToPoint2Params params = {}, bool async = true);
    void follow(const asset& path, float lookahead, int timeout,
                bool forwards = true, bool async = true);
    void moveForDistance(float dist, int timeout, MoveForDistanceParams params,
                         bool async = true);
    void cancelMotion();
    void cancelAllMotions();
    bool isInMotion() const;
    void resetLocalPosition();
    void waitUntil(float dist);
    void waitUntilDone();

   protected:
    void requestMotionStart();
    void endMotion();
    ControllerSettings lateralSettings;
    ControllerSettings angularSettings;
    OdomSensors sensors;
    Drivetrain dt;
    PID lateralPID;
    PID angularPID;
    ExitCondition lateralLargeExit;
    ExitCondition lateralSmallExit;
    ExitCondition angularLargeExit;
    ExitCondition angularSmallExit;
    bool motionRunning = false;
    bool motionQueued = false;
    float distTraveled = 0;

   private:
    pros::Mutex mutex;
};
}  // namespace evolib