#pragma once

#include "pros/rotation.hpp"
namespace evolib {
class TrackingWheel {
public:
  /**
   * @brief Create a new tracking wheel
   *
   * @param encoder the v5 rotation sensor to use
   * @param wheelDiameter the diameter of the wheel
   * @param distance distance between the tracking wheel and the center of
   * rotation in inches
   * @param gearRatio gear ratio of the tracking wheel, defaults to 1
   */
 TrackingWheel(pros::Rotation *rotSensor, float offset, float diameter);
 /**
  * @brief Reset the tracking wheel position to 0
  *
  */
 void reset();
 /**
  * @brief Get the distance traveled by the tracking wheel
  *
  * @return float distance traveled in inches
  */
 float getDistanceMoved();
 /**
  * @brief Get the offset of the tracking wheel from the center of rotation
  *
  * @return float offset in inches
  */
 float getOffset();
 float getDiameter();

private:
  float offset;
  float diameter;
  pros::Rotation *rotSensor = nullptr;
};
} // namespace evolib